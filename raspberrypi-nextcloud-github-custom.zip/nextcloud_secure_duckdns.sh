#!/bin/bash

set -e

echo "🚀 Updating system..."
sudo apt update && sudo apt upgrade -y

echo "📦 Installing Apache, MariaDB, PHP, Certbot..."
sudo apt install apache2 mariadb-server libapache2-mod-php php php-mysql php-gd php-xml php-mbstring php-curl php-zip php-intl php-bcmath unzip wget curl certbot python3-certbot-apache -y

echo "🔐 Setting up MariaDB for Nextcloud..."
sudo mysql -e "CREATE DATABASE nextcloud;"
sudo mysql -e "CREATE USER 'nextclouduser'@'localhost' IDENTIFIED BY 'nextcloudpass';"
sudo mysql -e "GRANT ALL PRIVILEGES ON nextcloud.* TO 'nextclouduser'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"

echo "📁 Installing Nextcloud..."
cd /var/www/
sudo wget https://download.nextcloud.com/server/releases/latest.zip
sudo unzip latest.zip
sudo chown -R www-data:www-data nextcloud
sudo chmod -R 755 nextcloud

echo "📝 Configuring Apache..."
sudo bash -c 'cat > /etc/apache2/sites-available/nextcloud.conf <<EOF
<VirtualHost *:80>
  DocumentRoot /var/www/nextcloud
  ServerName YOUR_DUCKDNS_SUBDOMAIN.duckdns.org

  <Directory /var/www/nextcloud/>
    Require all granted
    AllowOverride All
    Options FollowSymlinks MultiViews
  </Directory>

  ErrorLog \${APACHE_LOG_DIR}/error.log
  CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF'

sudo a2ensite nextcloud.conf
sudo a2enmod rewrite headers env dir mime
sudo systemctl reload apache2

read -p "🌐 Enter your DuckDNS domain (e.g., mypi.duckdns.org): " DUCKDNS_DOMAIN
read -p "🗝️  Enter your DuckDNS token: " DUCKDNS_TOKEN

echo "🟢 Setting up DuckDNS client for dynamic IP updates..."
mkdir -p ~/duckdns
cat > ~/duckdns/duck.sh <<EOF
echo url=\"https://www.duckdns.org/update?domains=$DUCKDNS_DOMAIN&token=$DUCKDNS_TOKEN&ip=\" | curl -k -o ~/duckdns/duck.log -K -
EOF
chmod 700 ~/duckdns/duck.sh
(crontab -l 2>/dev/null; echo "*/5 * * * * ~/duckdns/duck.sh >/dev/null 2>&1") | crontab -

echo "🔐 Getting HTTPS certificate from Let's Encrypt..."
sudo certbot --apache -d $DUCKDNS_DOMAIN --non-interactive --agree-tos -m your@email.com

echo "🔁 Setting up HTTPS redirection..."
sudo sed -i '/<\/VirtualHost>/i RewriteEngine On\nRewriteCond %{HTTPS} off\nRewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI}' /etc/apache2/sites-available/000-default.conf

echo "🔄 Restarting Apache..."
sudo systemctl restart apache2

echo "✅ Done! Open this in your browser:"
echo "➡️ https://$DUCKDNS_DOMAIN"

echo "💡 Use 'nextclouduser' / 'nextcloudpass' during the database setup in the Nextcloud wizard."
